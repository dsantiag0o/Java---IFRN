

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletUnimed
 */
@WebServlet("/ServletUnimed.do")
public class ServletUnimed extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletUnimed() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String especialidade = request.getParameter("especialidade");
		
		String nomeClinica = request.getParameter("nomeClinica");
		String endereco= request.getParameter("endereco");
		String telefone = request.getParameter("telefone");
		
		String nomeProfissional = request.getParameter("nomeProfissional");
		String crm = request.getParameter("crm");
		String especialidadeC = request.getParameter("especialidadeC");
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		Dao dao = new Dao();
		
		List<Profissional> profissionais = dao.getProfissionais(especialidade);
		
		PrintWriter saida = response.getWriter();
		response.setContentType("text/html");
		response.setCharacterEncoding("UTF-8");
		
		saida.append("<html>");
		saida.append("<head>");
		saida.append("<title>");
		saida.append("Bem-Vindo!");
		saida.append("</title>");
		saida.append("</head>");
		saida.append("<body>");
		saida.append("<h1>M�dicos</h1>");
		saida.append("<table border=\"1\">");
		
		saida.append("<tr>");
		saida.append("<td><b>");
		saida.append("Id");
		saida.append("</b></td>");
		
		saida.append("<td><b>");
		saida.append("Nome");
		saida.append("</b></td>");
		
		saida.append("<td><b>");
		saida.append("Crm");
		saida.append("</b></td>");
		saida.append("</tr>");
		
		for(Profissional p : profissionais){
			
			saida.append("<tr>");
			saida.append("<td>");
			saida.append(""+p.getId());
			saida.append("</td>");
			
			saida.append("<td>");
			saida.append(p.getNome_profissional());
			saida.append("</td>");
			
			saida.append("<td>");
			saida.append(""+p.getCrm());
			saida.append("</td>");
			
			saida.append("</tr>");
			
		}
		
		saida.append("</table>");
		saida.append("</body>");
		saida.append("</html>");
		
	}

}
