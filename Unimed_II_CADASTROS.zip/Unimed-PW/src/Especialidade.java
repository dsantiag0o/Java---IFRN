
public class Especialidade {
	
	private String nome_especialidade;
	private int id;
	public Especialidade() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Especialidade(String nome_especialidade) {
		super();
		this.nome_especialidade = nome_especialidade;
		this.id = id;
	}
	public String getNome_especialidade() {
		return nome_especialidade;
	}
	public void setNome_especialidade(String nome_especialidade) {
		this.nome_especialidade = nome_especialidade;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
}
