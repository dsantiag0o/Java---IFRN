import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Dao {
	
	private Connection connection;
	
	public Dao() {
		this.connection = new FabricaConexao().getConnection();
	}
	
	private static final String COMANDO_SELECT = "Select profissional.id, profissional.nome_profissional, profissional.crm From especialidade Inner Join especialidade_profissional On especialidade_profissional.especialidade_id = especialidade.id Inner Join profissional On especialidade_profissional.profissional_id = profissional.id Where nome_especialidade = ?;";
	private static final String COMANDO_INSERT_PROFISSIONAL = "Insert into profissional(nome_profissional, crm) Values(?,?)";
	private static final String COMANDO_INSERT_CLINICA = "Insert into clinica(nome_fantasia,endereco,telefone) Values(?,?,?)";
	private static final String COMANDO_INSERT_ESPECIALIDADE= "Insert into especialidade(nome_especialidade) Values(?)";
	
	public List<Profissional> getProfissionais(String especialidade){
		try {
			
			List<Profissional> profissionais = new ArrayList <Profissional>();
			
			if(this.connection!=null){
				System.out.println("Conectado com sucesso!!");
				PreparedStatement stmt = this.connection
						.prepareStatement(COMANDO_SELECT);
				stmt.setString(1, especialidade);
				
				ResultSet rs = stmt.executeQuery();
				
				//Pegando os resultados do Select*From...
				
				while(rs.next()){
					
				Profissional p = new Profissional();
				
				p.setId(rs.getInt("id"));
				p.setNome_profissional(rs.getString("nome_profissional"));
				p.setCrm(rs.getInt("crm"));
				
				profissionais.add(p);
				}
				rs.close();
				stmt.close();
				this.connection.close();
			
			
			}else{
				System.out.println("NÃO CONECTADO...");
			}
			return profissionais;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public boolean adicionarProfissional(Profissional profissional) {
		boolean retorno = false;
		try {
			PreparedStatement stmt = this.connection.prepareStatement(COMANDO_INSERT_PROFISSIONAL);
			// inserindo os valores...
		
			stmt.setString(1, profissional.getNome_profissional());
			stmt.setInt(2, profissional.getCrm());
			
			if (stmt.executeUpdate() > 0) {
				// Inseriu com sucesso
				retorno = true;

			} else {
				// Falha na inser��o
				retorno = false;
			}

			stmt.close();
			this.connection.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return retorno;
	}
	
	public boolean adicionarClinica(Clinica clinica) {
		boolean retorno = false;
		try {
			PreparedStatement stmt = this.connection.prepareStatement(COMANDO_INSERT_CLINICA);
			// inserindo os valores...
			
			stmt.setString(1, clinica.getNome_fantasia());
			stmt.setString(2, clinica.getEndereco());
			stmt.setString(3, clinica.getTelefone());

			if (stmt.executeUpdate() > 0) {
				// Inseriu com sucesso
				retorno = true;

			} else {
				// Falha na inser��o
				retorno = false;
			}

			stmt.close();
			this.connection.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return retorno;
	}
	
	public boolean adicionarEspecialidade(Especialidade especialidade) {
		boolean retorno = false;
		try {
			PreparedStatement stmt = this.connection.prepareStatement(COMANDO_INSERT_ESPECIALIDADE);
			// inserindo os valores...
			
			stmt.setString(1, especialidade.getNome_especialidade());


			if (stmt.executeUpdate() > 0) {
				// Inseriu com sucesso
				retorno = true;

			} else {
				// Falha na inser��o
				retorno = false;
			}

			stmt.close();
			this.connection.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return retorno;
	}

}
