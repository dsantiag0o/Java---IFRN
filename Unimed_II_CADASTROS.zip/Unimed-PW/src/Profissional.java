
public class Profissional {
	private int id;
	private String nome_profissional;
	private int crm;
	
	public Profissional( String nome_profissional, int crm) {
		super();
		this.nome_profissional = nome_profissional;
		this.crm = crm;
	}

	public Profissional() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome_profissional() {
		return nome_profissional;
	}

	public void setNome_profissional(String nome_profissional) {
		this.nome_profissional = nome_profissional;
	}

	public int getCrm() {
		return crm;
	}

	public void setCrm(int crm) {
		this.crm = crm;
	}
	
	
}
