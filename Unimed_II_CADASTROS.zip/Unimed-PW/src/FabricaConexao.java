import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class FabricaConexao {

		public Connection getConnection() {
			try {
				
				return DriverManager.getConnection(
						"jdbc:mysql://10.225.2.202:3306/unimed", "aluno", "aluno");
		            
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return null;
		}
	}