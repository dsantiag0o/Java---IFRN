
public class Clinica {
	private int id;
	private String nome_fantasia;
	private String endereco;
	private String telefone;
	public Clinica( String nome_fantasia, String endereco, String telefone) {
		super();
		this.nome_fantasia = nome_fantasia;
		this.endereco = endereco;
		this.telefone = telefone;
	}
	public Clinica() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome_fantasia() {
		return nome_fantasia;
	}
	public void setNome_fantasia(String nome_fantasia) {
		this.nome_fantasia = nome_fantasia;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	

}
