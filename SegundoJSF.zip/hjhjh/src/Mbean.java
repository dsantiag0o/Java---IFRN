import java.util.ArrayList;
import java.util.Collections;

import javax.faces.bean.ManagedBean;

@ManagedBean
public class Mbean {
	
	private ArrayList<Integer> numeros = new ArrayList<Integer>();
	private ArrayList<Integer> numerosSorteados = new ArrayList<Integer>();
	private int a;
	private int b;
	private int c;
	private double resultado;
	
	public double getResultado() {
		return resultado;
	}

	public void setResultado(double resultado) {
		this.resultado = resultado;
	}

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public int getC() {
		return c;
	}

	public void setC(int c) {
		this.c = c;
	}

	
	
	public ArrayList<Integer> gerarNumeros(){
		
		for (int i=1; i<=60; i++){
			numeros.add(i);
		}
		Collections.shuffle(numeros);
		for(int j=1; j<=6; j++){
			numerosSorteados.add(numeros.get(j));
		}
		return numerosSorteados;
	}
	
	public ArrayList<Integer> getNumerosSorteados() {
		return numerosSorteados;
	}

	public void setNumerosSorteados(ArrayList<Integer> numerosSorteados) {
		this.numerosSorteados = numerosSorteados;
	}	
	
	public double segundoGrauX1(){
		return resultado=((-b+(Math.sqrt((b*b)-(4*a*c))))/(2*a));
		
	}
	public double segundoGrauX2(){
		return resultado=((-b-(Math.sqrt((b*b)-(4*a*c))))/(2*a));
		
	}
		
}
			
